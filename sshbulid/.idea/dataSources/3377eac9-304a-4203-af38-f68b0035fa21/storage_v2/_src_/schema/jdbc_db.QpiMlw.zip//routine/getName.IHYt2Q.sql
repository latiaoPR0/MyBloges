create
    definer = root@localhost procedure getName(IN i int, OUT n varchar(50))
BEGIN

SELECT name INTO n FROM student WHERE id = i;

END;

